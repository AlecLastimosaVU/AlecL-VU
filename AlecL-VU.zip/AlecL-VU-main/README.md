-Website Development Documentation-

-Introdution-

This project is a single landing page website designed to practice HTML and CSS skills for a made-up running shoe, the FleetFoot X1.


-Website Structure-
1. Project Folder [ALECL-VU-MAIN]
    - index.html
    - README.md
    - styles.css


-How the Code is Structured- 

